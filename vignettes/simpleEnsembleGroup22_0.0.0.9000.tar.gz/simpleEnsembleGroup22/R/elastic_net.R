#' Elastic Net Regression with Cross-Validated Alpha Selection
#'
#' Fits an elastic net regression model with cross-validated alpha selection.
#'
#' @param X Matrix of predictors (independent variables), can be a mix of continuous, discrete, and binary predictors
#' @param y Response variable (binary or continuous)
#' @return Fitted model object
#' @examples
#' # Generate some sample data
#' set.seed(123)
#' n <- 100
#' p <- 10
#' X <- matrix(rnorm(n * p), ncol = p)
#' beta <- rnorm(p)
#' y <- X %*% beta + rnorm(n)
#'
#' # Fit the elastic net regression model
#' model <- elastic_net_regression(X, y)
#'
#' # Print the optimal alpha and lambda values
#' print(paste("Optimal Alpha:", model$opt.alpha))
#' print(paste("Optimal Lambda:", model$opt.lambda))
#'
#' # Make predictions using the fitted model
#' predictions <- model$predicted.value
#'
#' # Print the first few predictions
#' print(head(predictions))
#'
#' @export
elastic_net_regression <- function(X, y) {
  if(!is.matrix(X)){
    X <- as.matrix(X)
  }

  # Determine the type of response variable
  family_type <- if (all(y %in% c(0, 1))) "binomial" else "gaussian"

  alph_lamb <- data.frame(matrix(ncol=3, nrow=0))
  alphavec = seq(0,1,0.1)
  for (i in 1:length(alphavec)){
    # Fit the elastic net using cross-validation
    fit <- glmnet::cv.glmnet(X, y, family = family_type, alpha=alphavec[i], nfolds = 10)

    min_mse <- min(fit$cvm)
    lam <- fit$lambda[which(fit$cvm == min_mse)]
    alph_lamb <- rbind(alph_lamb, c(alphavec[i], lam, min_mse))
  }
  colnames(alph_lamb) <- c("alpha", "lambda", "cvm")
  min_cvm <- min(alph_lamb$cvm)
  opt_alpha <- alph_lamb[which(alph_lamb$cvm == min_cvm),1]
  opt_lambda <- alph_lamb[which(alph_lamb$cvm == min_cvm),2]
  fit_final <- glmnet::glmnet(X,y, family = family_type, alpha = opt_alpha, lambda = opt_lambda)
  return(list(model = fit_final, optimal.alpha = opt_alpha, predicted.value = predict(fit_final, newx = X, type = "response", s = opt_lambda)))

}
