#' Simple Ensemble Learning
#'
#' This function performs ensemble learning using a combination of linear models (such as Elastic Net) and tree-based models (such as Random Forest).
#' It conducts preliminary data screening, trains multiple models, and optionally performs ensemble learning.
#'
#' @param X Matrix of predictors (independent variables).
#' @param y Response variable (dependent variable).
#' @param models A character vector specifying the types of models to include in the ensemble. Options include "elastic.net" and "random.forest".
#' @param k Number of predictors to select in the pre-screening step. Default is half the number of predictors.
#' @param r.bagging Number of times to perform bagging for each model. Default is 50.
#' @param is.ensemble Logical indicating whether to perform ensemble learning. Default is FALSE.
#'
#' @return A list containing the results of the ensemble learning process.
#'
#' The returned list includes the results of training and evaluating individual models specified in 'models', as well as the ensemble model if 'is.ensemble' is TRUE.
#'
#' @export
#' @examples
#' # Example usage:
#' # Generate some sample data
#' set.seed(123)
#' n <- 1000
#' p <- 10
#' X <- matrix(rnorm(n * p), ncol = p)
#' y <- sample(0:1, n, replace = TRUE)
#'
#' # Call simple_ensemble_group_22 function with Elastic Net and Random Forest models
#' results <- simple_ensemble_group_22(X, y, models = c("elastic_net"), r.bagging = 50, is.ensemble = FALSE, k = NULL)
#'
#' # Print the results
#' print(results)
simple_ensemble_group_22 <- function(X, y, models = c("elastic_net"), r.bagging = NULL, is.ensemble = FALSE, k = NULL) {
  # Pre-screening to check if provided data is valid
  if (is.null(X) || is.null(y)) {
    return("Either X and/or y is NULL")
  }
  # y either binary or continuous -- if cont. it is assumed to be normally dist.

  if (!is.numeric(y) || (is.factor(y) && length(unique(y)) > 2)) {
    return("The response variable must be numeric: either binary or continuous!")
  }

  # Identify if all column's data types are acceptable: X can be continuous, discrete, binary
  if (!all(sapply(X, function(x) is.numeric(x) || (is.factor(x) && length(unique(x)) == 2)))) {
    return("The predictor variable must be numeric: binary, discrete, or continuous.")
  }

  # Process missing data: replace with column median value
  data.mat <- cbind(y, X)
  if (any(is.na(data.mat))) {
    # Calculate column-wise medians
    medians <- colMedians(data.mat, na.rm = TRUE)
    data.mat <- t(apply(data.mat, 1, function(x) ifelse(is.na(x), medians, x)))
    X <- data.mat[, -1]
    y <- data.mat[, 1]
  }

  # variable pre-screening
  X <- variable_pre_screening(X, y, k)

  # If y is a factored variable, convert it into a binary variable
  if (is.factor(y)) {
    y <- as.numeric(y) - 1
  }
  # Process X for categorical/non-numeric variable
  if (!all(sapply(X, function(x) is.numeric(x)))) {
    df <- data.frame(y, X)
    X <- model.matrix(y ~ ., df)[, -1]
  }

  results <- list()

  for (modeltype in models) {
    if (!is.null(r.bagging)) {
      print("Bagging is being done - ")
      result <- bagged_model(X, y, r.bagging, modeltype)
    } else {
      print("List of models given - ")
      print(modeltype)
      # call the appropriate model using switch
      result <- switch(modeltype,
        linear = linear_model(X, y),
        ridge = ridge_model(X, y),
        lasso = lasso_model(X, y),
        elastic_net = elastic_net_regression(X, y),
        random_forest = rf_model(X, y)
      )
    }
    results[[modeltype]] <- result
  }

  if (is.ensemble) {
    print("Ensemble is being done - ")
    results[["ensembled"]] <- ensemble_predict(X, y)
  }

  return(results)
}
